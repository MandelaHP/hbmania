<!DOCTYPE html>
<html lang="br-pt">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<base href="http://habbonight.com.br" />
<title>HabboNight - A noite � apenas uma parte do dia!</title>
<meta name="description" content="A HabboNight &eacute; uma F&atilde; Site Oficial do Habbo BR/PT, aqui voc&ecirc; encontra not&iacute;cias do Habbo e do mundo, r&aacute;dio com os melhores locutores, eventos/promo&ccedil;&otilde;es, FanCenter, f&oacute;rum para discuss&otilde;es e v&aacute;rias outras ferramentas para voc&ecirc; se destacar ainda mais no mundo de pixels" />
<link href="ico.png" rel="icon" type="image/x-icon">
<link type="text/css" href="media/css/estilo.css?1464818693" rel="stylesheet" />
<link type="text/css" href="media/css/nightsena.css?1414985910" rel="stylesheet" />
<link type="text/css" href="media/css/jquery-ui.css" rel="stylesheet" />
<link type="text/css" href="estilo_new.css" rel="stylesheet" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<script type="text/javascript" src="media/js/jquery-ui.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script type="text/javascript" src="media/js/jquery.cycle.all.min.js"></script>
<script type="text/javascript" src="media/js/colortip-1.0-jquery.js"></script>
<link rel="stylesheet" type="text/css" href="media/css/colortip-1.0-jquery.css"/>
<script type="text/javascript" src="media/js/principal.js?1433481698"></script>
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<link rel="stylesheet" type="text/css" href="media/css/shadowbox.css">
<script type="text/javascript" src="media/js/shadowbox.js"></script>
<script type="text/javascript">
Shadowbox.init({
    handleOversize: "drag",
    modal: true
});
</script>
<script>
function alerta_iniciar() {
	$.ajax({
		type: 'POST',
		dataType: 'json',
		data: {'verificar': 'sim'},
		url: 'lib/recebe_alerta.php',
		success: function(data) {
			if(data.erro == 'nao'){
				alerta.inicia(data.texto+'<div style="clear:both"></div><div style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?user='+data.autor+'&action=std&direction=4&head_direction=3&gesture=sml&size=b) 0px -10px; width:64px; height:54px; float:right;"></div><div id="quemfez">Enviado por: <a href="home/'+data.autor+'">'+data.autor+'</a><br>em '+data.datee+' �s '+data.horaa+'</div><div style="clear:both"></div>');
			}
		}
	});

setTimeout('alerta_iniciar();', 50000);
}
window.onload=alerta_iniciar();

</script>


</head>

<body>
<div id="abrangente">
<div id="banner">
<div id="sobre">
	<div id="barraesquerda">
	</div>
	<div id="barradireita"></div>

	<div style="width:1000px; margin:0 auto;">
	
 


		<div id="lua"></div>
		<div id="slides">
     	   <div id="pass_s"></div>
			<div id="slide">
				<ul>
					<li><a href="http://habbonight.com.br/bilhete" ><img src="/media/acervo/2015/05/eb2ae0e9119ad93c38db817cbde7b583.png"/><div id="texto">#NightALOKA - Show de PR�MIOS!!!<br /><span>Participe do grande sorteio! Escolha os seus bilhetes agora mesmo...</span></div></a></li>     
					<li><a href="http://habbonight.com.br/noticia/5518-pesquisa-de-campo--habbonight" ><img src="/media/acervo/2015/05/db71a38261fd98274e9b8d85bf5fc706.png"/><div id="texto">Pesquisa de Campo HN!<br /><span>Participe da pesquisa e ganhe um emblema exclusivo + 12 jabuticabas!</span></div></a></li>     
					<li><a href="http://www.soundcloud.com/produtorasoundmax" target="_blank"><img src="/media/acervo/2015/05/e55208768c9e90531847addb3c7c312a.png"/><div id="texto"><br /><span></span></div></a></li>     
					<li><a href="" ><img src="/media/acervo/2015/05/6f79bf31dc32fc8b700eebc81163df93.png"/><div id="texto">Pol�cia DIC<br /><span>Nosso parceiro destaque da HabboNight!</span></div></a></li>     
					<li><a href="http://www.twitter.com/Habbonight" target="_blank"><img src="/media/acervo/2015/05/04ce661c72.png"/><div id="texto">Confira o TWITTER da Habbonight<br /><span>Siga-nos e fique por dentro de tudo!</span></div></a></li>     
				</ul>
			</div>
        </div>
		<div style="width:347px; height:347px; float:right; margin-top:90px">
		<a href="index.php"><div id="logo"></div></a>
		<div id="login">
			<form action="javascript:;" id="form_logar">
				<div id="icone_user"><input class="input" id="inpt_usuario" type="text" placeholder="Usu�rio" /></div>
				<div id="icone_senha"><div id="botao_visu_s" class="fa fa-eye" style="color:#666; position:absolute; cursor:pointer; margin-left:175px; margin-top:10px;;font-size:16px;"></div><input class="input" id="inpt_senha" type="password" placeholder="***********" /></div>
				<div style="margin-left:20px; padding:4px;"><input id="lembrar" type="checkbox" /> Lembrar minha senha</div>
				<div id="botoes_login"><a href="registrar"><div id="cadastro"></div></a><input type="submit" id="inptt" value="" /></div>
			</form>
		</div>
	</div>
	<div id="marcio_muda" style="height:488px; float:left"></div><div id="menu">
	<div id='cssmenu'>
	<ul>
		<li class='active'><a href='index.php'><span>Home</span></a></li>
		<li class='has-sub'><a href='#'><span><div style="position:absolute; font-family:Tahoma; font-weight:bold; font-size:8px; color:#a4000a; margin-left:-15px; margin-top:-13px;">NEW</div>HabboNight</span></a>
			<ul>
				<li><a href="habbonight/equipe"><span>Equipe</span></a></li>
				<li><a href="formulario-cargo"><span><div id="new" style="position:absolute; font-family:Tahoma; font-weight:bold; font-size:8px; color:#a4000a; margin-left:115px; margin-top:-13px;">NEW</div>Seja da equipe</span></a></li>
				
				<li style="background:url(media/imagens/seta_menu.png) no-repeat 180px 13px;"><a href=""><span>Parceiros</span></a>
				<div class="sumemo"><ul style="margin-left:-5px; margin-top:-35px;">
				<li><a href="pagina/375-parceiros"><span>Parceiros</span></a></li> 
				
						<li><a href="habbonight/parceiros"><span>Parceiros HabboNight</span></a></li>
					</ul></div>
				</li>
								
				<li style="background:url(media/imagens/seta_menu.png) no-repeat 180px 13px;"><a href=""><span>Aplicativos</span></a>
					<div class="sumemo"><ul style="margin-left:-5px; margin-top:-35px;">
						<li><a href="nightsena"><span>NightSena</span></a></li>
					</ul></div>
				</li>
				<li><a href="pagina/409-regras-da-lets-shopping"><span>Regras da Lets Shopping</span></a></li> 
				<li><a href="pagina/401-verses"><span>Vers�es</span></a></li> 
				<li><a href="pagina/399-night-points"><span>Night Points</span></a></li> 
				<li><a href="pagina/398-histria"><span>Hist�ria</span></a></li> 
				<li><a href="pagina/396-anncios"><span>An�ncios</span></a></li> 
				<li><a href="pagina/394-connect-night"><span>Connect Night</span></a></li> 

				<li><a href="lets"><span>Lets Shopping</span></a></li> 
<li><a href="usuario/usuarios-online"><span>Usu�rios online</span></a></li>
				
			</ul>
		</li>
		<li class='has-sub'><a href='#'><span>Habbo</span></a>
			<ul>
				<li><a href="pagina/404-staffs"><span>Staffs</span></a></li> 
				<li><a href="pagina/403-catlogo"><span>Cat�logo</span></a></li> 
			</ul>
		</li>
		<li class='has-sub'><a href='#'><span>Not�cias</span></a>
			<ul>
				<li><a onclick="noticias.categoria('1', '1')" href="javascript:void()"><span>Coisas gr�tis</span></a></li>
				<li><a onclick="noticias.categoria('2', '1')" href="javascript:void()"><span>Colunas</span></a></li>
				<li><a onclick="noticias.categoria('3', '1')" href="javascript:void()"><span>Emblemas</span></a></li>
				<li><a onclick="noticias.categoria('4', '1')" href="javascript:void()"><span>Habbo Hotel BR/PT/AO</span></a></li>
				<li><a onclick="noticias.categoria('5', '1')" href="javascript:void()"><span>Habbo Internacional</span></a></li>
				<li><a onclick="noticias.categoria('6', '1')" href="javascript:void()"><span>HabboNight</span></a></li>
				<li><a onclick="noticias.categoria('7', '1')" href="javascript:void()"><span>Not�cias Mundo</span></a></li>
				<li><a onclick="noticias.categoria('8', '1')" href="javascript:void()"><span>Promo��es/Eventos</span></a></li>
				<li><a onclick="noticias.categoria('9', '1')" href="javascript:void()"><span>R�dio</span></a></li>
				<li><a onclick="noticias.categoria('10', '1')" href="javascript:void()"><span>Sulake</span></a></li>
			</ul>
		</li>
		<li class='has-sub'><a href='#'><span>R�dio</span></a>
			<ul>
				<li><a href="horarios"><span>Hor�rios</span></a></li> 
				<li><a href="pagina/382-seja-um-locutor"><span>Seja um Locutor</span></a></li> 
				<li><a href="radio/ranking-locutores"><span>Ranking de locutores</span></a></li>
		 	</ul>
		</li>
		<li class='has-sub'><a href='#'><span>Usu�rio</span></a>
			<ul>
				<li><a href="usuario/registrar"><span>Registre-se</span></a></li>
				<li><a href="usuario/recuperar"><span>Recuperar senha</span></a></li>

				<li><a href="usuario/usuarios-online"><span>Usu�rios online</span></a></li>
			</ul>
		</li>

		<li class='has-sub'><a href='#'><span>F�Center</span></a>
			<ul>
				<li><a href="facenter/habbo-imager"><span>Habbo Imager</span></a></li> 
				<li><a href="facenter/balao-fala"><span>Bal�o de Fala</span></a></li> 
				<li><a href="facenter/gerador-banzai"><span>Gerador Banzai</span></a></li> 
				<li><a href="facenter/gerador-sofa"><span>Gerador de Sof�</span></a></li> 
				<li><a href="facenter/gerador-beijo"><span>Gerador de Beijo</span></a></li> 
				<li><a href="facenter/gerador-letra"><span>Gerador de Letras</span></a></li> 

				<li><a href="facenter/scanner-emblemas"><span>Scanner de Emblemas</span></a></li> 
				<li><a href="facenter/scanner-amigos"><span>Scanner de Amigos</span></a></li> 

			</ul>
		</li>
		<li class='has-sub'><a href='#'><span>Pixel-Artes</span></a>
		
			<ul>
							</ul>
			
			</li>
		<li class='has-sub'><a href='#'><span>F�rum</span></a>
			<ul>

				<li><a href="pagina/402-segurana"><span>Seguran�a</span></a></li> 
							<li><a href="pagina/400-regras-do-frum"><span>Regras do F�rum</span></a></li> 
				
			
				<li><a href="ranking-forum"><span>Ranking do f�rum</span></a></li>
			
			</ul>	
		</li>

		<li class='has-sub'><a href='valores'><span>Valores</span></a></li>
		
	</ul>
	</div>

</div>
</div>
</div>
</div>


		<div id="notifica_exibe"></div>




<a href="http://habbonight.com.br/registrar"><div style='width:954px;background-color:#44B600;border-bottom:5px solid rgba(0,0,0,0.25);padding:13px;font-family:"Segoe UI";font-size:12px;text-shadow:0px 1px rgba(0,0,0,0.5);color:#fff;cursor:pointer;border-radius:5px;margin:auto;margin-top:50px;
margin-bottom:-40px;'>

<i class="fa fa-exclamation-circle" style="font-size:16px; margin-right:5px;"></i> <b>Cadastre-se j�!</b><br />Voc� pode aproveitar todas as vantagens da HabboNight criando uma conta. Junte-se � nossa comunidade agora mesmo!</div></a>
<div style="width:1000px; margin:50px auto;">



<div style="width:850px; margin:0px auto; min-height:300px;">

<div id="noticias_atualiza">
<div id="noticias_btns">
<div id="seleciona"><div id="seta_arruma"></div>Categorias
	<div id="ops">
		<div onclick="noticias.pagina('1')">Todas</div>
		<div onclick="noticias.categoria('1', '1')">Coisas gr�tis</div>
		<div onclick="noticias.categoria('2', '1')">Colunas</div>
		<div onclick="noticias.categoria('3', '1')">Emblemas</div>
		<div onclick="noticias.categoria('4', '1')">Habbo Hotel BR/PT/AO</div>
		<div onclick="noticias.categoria('5', '1')">Habbo Internacional</div>
		<div onclick="noticias.categoria('6', '1')">HabboNight</div>
		<div onclick="noticias.categoria('7', '1')">Not�cias Mundo</div>
		<div onclick="noticias.categoria('8', '1')">Promo��es/Eventos</div>
		<div onclick="noticias.categoria('9', '1')">R�dio</div>
		<div onclick="noticias.categoria('10', '1')">Sulake</div>
	</div>
</div>
<div id="esquerda" style="opacity:0.5"></div>
<div id="atualiza" onclick="noticias.pagina('1')"></div>
<div id="direita" onclick="noticias.pagina('2')"></div>
</div>
<div class="titulo" style="margin-left:15px;">�rea de not�cias</div>

 <a href="noticia/5557-revista-habbo-16-"><div id="imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/0665c354a4.png) repeat center;" title="Revista Habbo #16 "><div id="frente-imagem" style="border-top:3px solid #444444"><div class="titulo_noticia">Revista Habbo #16...</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/6.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">12/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 

(Trilha sonora de tambores de jogos vorazes)

... Olha EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEla de volta aqui na Hab... </div>
 </div></div></a>
  <a href="noticia/5556-combate-ao-trabalho-infantil"><div id="imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/9d5e4deafb.png) repeat center;" title="Combate ao Trabalho Infantil"><div id="frente-imagem" style="border-top:3px solid #EFBA24"><div class="titulo_noticia">Combate ao Trabal...</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/8.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">12/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 

Al&eacute;m do nosso belo e romantico Dia dos Namorados, hoje tamb&eacute;m &eacute; um dia muito importante para todo... </div>
 </div></div></a>
  <a href="noticia/5555-resumo-semanal-1"><div id="imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/626e9979d2.png) repeat center;" title="Resum�o Semanal #1"><div id="frente-imagem" style="border-top:3px solid #59B200"><div class="titulo_noticia">Resum�o Semanal #...</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/4.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">12/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 



O Resum&atilde;o Semanal &eacute; um projeto que foi desenvolvido com o objetivo de informar, e relembrar as princ... </div>
 </div></div></a>
  <a href="noticia/5550-emblemas-de-junho-1"><div id="imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/692a29234b.jpg) repeat center;" title="Emblemas de Junho #1"><div id="frente-imagem" style="border-top:3px solid #EF24EF"><div class="titulo_noticia">Emblemas de Junho...</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/3.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">11/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 

Um artista procura em todos os detalhes de suas obras um problema, para poder aperfei&ccedil;o&aacute;-lo futuramente,... </div>
 </div></div></a>
  <a href="noticia/5548-ender-wars"><div id="imagem" style="background:url(http://habbonight.com.br/media/acervo/2015/05/60a1768c7f.png) repeat center;" title="Ender Wars"><div id="frente-imagem" style="border-top:3px solid #EFBA24"><div class="titulo_noticia">Ender Wars</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/8.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">10/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 

Desde que o homem evoluiu a m&aacute;quina ao ponto de conseguir ir ao espa&ccedil;o, o avan&ccedil;o tecnol&oacute;gi... </div>
 </div></div></a>
  <a href="noticia/5544-raro-selvana-perdida"><div id="imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/7bf699cb58.png) repeat center;" title="Raro Selvana Perdida"><div id="frente-imagem" style="border-top:3px solid #59B200"><div class="titulo_noticia">Raro Selvana Perd...</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/4.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">10/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 

Em cada campanha do Habbo s&atilde;o disponibilizadas diversas mob&iacute;lias &ldquo;raras&rdquo;, na qual ficam um p... </div>
 </div></div></a>
  <a href="noticia/5540-o-bug-mortal"><div id="imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/466bfca7e4.gif) repeat center;" title="O bug mortal"><div id="frente-imagem" style="border-top:3px solid #00FFFF"><div class="titulo_noticia">O bug mortal</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/10.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">06/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 

Durante este s&aacute;bado (04/06) foram encontradosdois bugs no cat&aacute;logo dos hot&eacute;is o que surpreendeu m... </div>
 </div></div></a>
  <a href="noticia/5539-cabana-abandonada"><div id="imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/38b463952c.png) repeat center;" title="Cabana Abandonada"><div id="frente-imagem" style="border-top:3px solid #59B200"><div class="titulo_noticia">Cabana Abandonada</div> 
<div id="redondo1"><div style="background-image:url(media/imagens/flags/4.png)"></div></div>


<div style="border:rgba(41, 40, 40, 0.52) solid 1px;height: 26px;width: 83px;border-radius: 5px;background:rgba(0, 0, 0, 0.46);">
	<div style="font-family: Tahoma;font-weight: bold;color: #fff;margin-left: 5px;font-size: 10px;padding: 3px;margin-top: 3px;">06/06/2016</div>
</div>

 <div id="branco_noticia" style="margin:48px 3px;">
 

As novidades no Habbo n&atilde;o param! Todos os dias s&atilde;o novos emblemas, c&oacute;digos, imagens, tudo para de... </div>
 </div></div></a>
 </div>

<style> #ev-eventos { 	background:rgba(0,0,0,0.3); 	width:269px; 	height:147px; 	border-radius:5px; 	padding:5px; 	float:left; 	margin-right:4px; 	margin-bottom:4px; 	transition: all 0.5s;} #ev-eventos #ev-imagem { 	width:269px; 	height:147px; 	border-radius:7px; 	transition: all 0.5s; 	-webkit-filter: blur(1px); -moz-filter: blur(1px); -o-filter: blur(1px); -ms-filter: blur(1px); filter: blur(1px);} #ev-eventos:hover #ev-imagem { 	-webkit-filter: blur(0px); -moz-filter: blur(0px); -o-filter: blur(0px); -ms-filter: blur(0px); filter: blur(0px);} #ev-eventos #ev-imagem #efeito { 	background:url(http://i.imgur.com/szeUgXc.png); 	width:269px; 	height:141px; 	font-size:20px; 	border-radius:7px; 	font-family:"Segoe UI"; 	text-transform: uppercase; 	text-shadow:0px 2px rgba(0,0,0,0.3); 	color:#fff; 	text-align:center; 	letter-spacing:-1px; 	padding-top:6px;} #ev-eventos #ev-imagem #efeito #ev-data { 	width:100px; 	height:100px; 	background:#FF5C26; 	border-radius:250px; 	margin:auto; 	box-shadow:0px 7px 0px rgba(0,0,0,0.3);} #ev-eventos #ev-imagem #efeito #ev-data div { 	font-size:40px; 	text-shadow:0px 3px rgba(0,0,0,0.3); 	font-weight:bold; 	letter-spacing:-3px; 	padding-top:10px; 	margin-bottom:-10px;} #ev-eventos #ev-imagem #efeito #ev-titulo { 	font-weight:bold; 	text-shadow:0px 3px rgba(0,0,0,0.3); 	padding-top:10px;} </style>
<div style="clear:both"></div>
<div id="eventos_atualiza">
<div id="noticias_btns" style="width:100px; margin-top:12px;">
<div id="esquerda" style="opacity:0.5"></div>
<div id="atualiza" onclick="noticias.eventos('1')"></div>
<div id="direita" onclick="noticias.eventos('2')"></div>
</div>
 <div class="titulo" style="margin-left:11px;">�rea de eventos</div>
 
 <a href="noticia/5556-combate-ao-trabalho-infantil"><div id="ev-eventos" title="Combate ao Trabalho Infantil">
	<div id="ev-imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/9d5e4deafb.png);">
		<div id="efeito">
			<div id="ev-data"><div>17</div>de Jun</div>
			<div id="ev-titulo">Combate ao Trabalho ...</div>
		</div>
	</div>
</div></a>
<a href="noticia/5548-ender-wars"><div id="ev-eventos" title="Ender Wars">
	<div id="ev-imagem" style="background:url(http://habbonight.com.br/media/acervo/2015/05/60a1768c7f.png);">
		<div id="efeito">
			<div id="ev-data"><div>20</div>de Jun</div>
			<div id="ev-titulo">Ender Wars</div>
		</div>
	</div>
</div></a>
<a href="noticia/5518-pesquisa-de-campo--habbonight"><div id="ev-eventos" title="Pesquisa de Campo - HabboNight">
	<div id="ev-imagem" style="background:url(http://habbonight.com.br/media/noticiasv6-2/90bddc9f60.jpg);">
		<div id="efeito">
			<div id="ev-data"><div>18</div>de Jun</div>
			<div id="ev-titulo">Pesquisa de Campo - ...</div>
		</div>
	</div>
</div></a>
 </div>



 
 </div>
<div style="clear:both;margin-top:20px;"></div>
<style>
#campanha_body{background:url(http://i.imgur.com/gqi0W3i.png) bottom;width:960px; margin:auto;padding:10px; padding-bottom:10px;box-shadow:0px 3px 0px rgba(0,0,0,0.45); border-radius:5px;}#title_termacio{font-family:'Segoe UI'; font-size:28px; color:#fff; text-shadow:0px 1px #000; font-weight:300; text-align:center; width:350px; padding:12px; background:rgba(0,0,0,0.8); border-radius:100px; margin:auto;}#barralaranja_termarcio{background:rgb(0,162,232); border-radius:100px; height:30px; font-family:Tahoma; font-size:16px; color:#fff;text-align:center; line-height:160%;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box; border:2px solid rgba(0,0,0,0.2)}#alinha_aa{ float:right}#toltip_campanha{background:#fff; font-size:12px; font-family:"Segoe UI"; color:#333; border-radius:5px; padding:5px 15px; position:absolute; margin-top:-50px; margin-left:-35px;-webkit-box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);-moz-box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);}#toltip_campanha:before {position:absolute;left:21px;top:36px;content:" ";height:0px;width:0px;border-right:6px solid transparent;border-left:6px solid transparent;border-top:6px solid #FFF;}
#minhas_jabus {
	width:300px;
	float:right;
	background:#fff;
	font-size:12px; font-family:"Segoe UI"; color:#333;
	-webkit-box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);-moz-box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);
	border-radius:5px;
	margin-top:20px;
	margin-right:20px;}
#minhas_jabus #right {
	float:right;
	font-size:22px;
	line-height:50px;
	padding-left:10px;
	padding-right:10px;
	border-left:1px solid rgba(0,0,0,0.1);
	cursor:pointer;}
#minhas_jabus #left {
	float:left;
	line-height:50px;
	padding-left:15px;}
	
#meta_atual {
	float:left;}
#meta_atual #corpo {
	width:310px;
	float:right;
	padding:15px;
	background:#fff;
	font-size:12px; font-family:"Segoe UI"; color:#333;
	-webkit-box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);-moz-box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);box-shadow: 0px 0px 6px 1px rgba(0,0,0,0.2);
	border-radius:5px;
	margin-top:10px;}
</style>
<div id="campanha_body" style="margin-top:76px;">
<div id="title_termacio">Campanha Jabuticaba</div>
<div style="width:954px;height:30px; background:rgba(0,0,0,0.5); border-radius:100px; padding:3px; margin:auto; margin-top:40px;"><div style="width:100%;" id="barralaranja_termarcio">
<div style="margin-left:21.666666666667px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:61.25px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:124.58333333333px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:211.66666666667px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:298.75px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:417.5px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:615.41666666667px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:718.33333333333px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div style="margin-left:940px; margin-top:5px;position:absolute;border:2px solid #0082ba; background:#fff; border-radius:250px; width:10px; height:10px;"></div>
<div id="alinha_aa"><div id="toltip_campanha">1638 jabuticabas</div></div>100%</div>
</div>
<div id="meta_atual">
<div style="background:url(http://habbonight.com.br/media/imagens/ranking_eventopascoa.png); width:351px; height:52px;margin-top:20px;">
<div style="font-family:'Myriad Pro';font-size:16px; font-weight:400; color:#fff; text-shadow:0px 2px rgba(0,0,0,0.3); float:left; height:42px; line-height:46px; margin-left:14px;">Metas conclu�das!</div></div>
</div>

<div style="clear:both"></div>
</div>
<div style="height:60px;"></div>
 
 <div style="clear:both;"></div>

<div style="background-color:rgba(23, 21, 47, 0.23);width:945px;height:120px; margin:30px auto;">
<div style="margin:0px 0px; position:absolute; 

">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- An�ncio HabboNight -->
<ins class="adsbygoogle"
     style="display:inline-block;width:945px;height:120px"
     data-ad-client="ca-pub-2985021028928902"
     data-ad-slot="2912509671"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</div> 




 <div id="box1000">
 <div id="traco_marelo"></div>
<div id="coisas_gratis">
<div id="emblemas_btns">
<div id="esquerda" style="opacity:0.5"></div>
<div id="direita" onclick="noticias.coisas_gratis('2')"></div>
</div>
<div class="titulo" style="margin-left:15px;">Gratuito para ganhar no Habbo Hotel BR/PT</div>
<a href="noticia/5554-amor-da-selva">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(https://images.habbo.com/c_images/album1584/V1200.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Amor da Selva</div>
 </div></a>
<a href="noticia/5553-habbgaryen">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://images.habbo.com/c_images/album1584/IT934.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Habbgaryen</div>
 </div></a>
<a href="noticia/5551-habbatheon">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://images.habbo.com/c_images/album1584/IT933.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Habbatheon</div>
 </div></a>
<a href="noticia/5549-bolo-da-sweetgham-cake">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://images.habbohotel.com/c_images/album1584/SE079.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Bolo da Sweetgham...</div>
 </div></a>
<a href="noticia/5547-bem-vindo-a-birmingham">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://images.habbo.com/c_images/album1584/PT097.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Bem-vindo a Birmi...</div>
 </div></a>
<a href="noticia/5545-dia-de-portugal-2016">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://images.habbo.com/c_images/album1584/PT098.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Dia de Portugal 2...</div>
 </div></a>
<a href="noticia/5543-habbstark">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://images.habbo.com/c_images/album1584/IT935.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Habbstark</div>
 </div></a>
<a href="noticia/5542-habbnister">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(https://images.habbo.com/c_images/album1584/IT936.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Habbnister</div>
 </div></a>
<a href="noticia/5541-tirolesa">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://images.habbohotel.com/c_images/album1584/ES802.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">Tirolesa</div>
 </div></a>
<a href="noticia/5397-bobbaman">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://habboo-a.akamaihd.net/c_images/album1584/PT053.gif) center no-repeat;"></div>
  

  <div class="emblemas_br">BobbaMan</div>
 </div></a>
<a href="noticia/4028-distribuidor-hipad">
 <div id="emblemas_br">  <div style="width:50px; float:left; border-radius:5px; min-height:50px; margin:8px 15px;background:url(http://habbonight.com.br/media/acervo/2015/05/d689341120.png) center no-repeat;"></div>
  

  <div class="emblemas_br">Distribuidor HiPa...</div>
 </div></a>
</div>

 <div style="clear:both;"></div>

 <div class="titulo" style="margin-left:15px;">�rea de cota��es</div>

	<a href="valores/mobi/9018-clube-sofa"><div id="valor_desceu" title="Mobi: <b>Clube Sof�</b><br>Valor: <b style='color:#F8B327'>17 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_7ff5475aea311a421d9fdba50709671f.gif) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9017-sorveteira-roxa"><div id="valor_desceu" title="Mobi: <b>Sorveteira Roxa</b><br>Valor: <b style='color:#F8B327'>1700 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_72706944455455cbdaaec060f3ebf394.gif) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9016-sorveteira-azul-de-gelo"><div id="valor_desceu" title="Mobi: <b>Sorveteira azul de gelo</b><br>Valor: <b style='color:#F8B327'>25 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_f6c297b247a6d0be18df5391117c4e99.png) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9015-sorveteira-azul"><div id="valor_desceu" title="Mobi: <b>Sorveteira Azul</b><br>Valor: <b style='color:#F8B327'>30 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_a5b4544d12db70decba12aad7eae272e.gif) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9014-sorveteira-vermelha"><div id="valor_desceu" title="Mobi: <b>Sorveteira Vermelha</b><br>Valor: <b style='color:#F8B327'>30 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_aec92a20cf52ff4173b112f55795ef87.gif) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9013-maquina-de-chocolate-quente"><div id="valor_desceu" title="Mobi: <b>M�quina de Chocolate Quente</b><br>Valor: <b style='color:#F8B327'>70 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_0f0118ace37e7498b47c532e9e8c2dbf.png) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9012-boneco-de-vodu"><div id="valor_subiu" title="Mobi: <b>Boneco de Vodu</b><br>Valor: <b style='color:#F8B327'>70 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_a36169e7ce78ed081804e71162b46222.png) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9011-chefe-do-pato-do-mal"><div id="valor_normal" title="Mobi: <b>Chefe do Pato do Mal</b><br>Valor: <b style='color:#F8B327'>10 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_5a8d7ede5d2ed017d6f22518f8f19b4c.gif) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9010-snooker-bling"><div id="valor_normal" title="Mobi: <b>Snooker Bling</b><br>Valor: <b style='color:#F8B327'>45 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_311bdb637ff1265bd54a3d1a828b8762.png) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9009-perola-luminosa-do-amor"><div id="valor_desceu" title="Mobi: <b>P�rola Luminosa do Amor</b><br>Valor: <b style='color:#F8B327'>10 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_87e2c6dec5e71ee7fc0f701a5fdd6d69.png) center no-repeat;"></div>
	</div></a>
	<a href="valores/mobi/9008-polvo-invasor"><div id="valor_normal" title="Mobi: <b>Polvo Invasor</b><br>Valor: <b style='color:#F8B327'>15 C�mbios</b><br>Adicionado por: Francys,">
		<div style="width:40px; float:left; border-radius:5px; min-height:40px; margin:8px 20px;background:url(http://habbonight.com.br/media/valores/P_868c28f7a6c10751c74dcf0cba54e167.gif) center no-repeat;"></div>
	</div></a>
 
<style>#coments_topic {position: absolute;padding:5px;padding-top:3px;padding-bottom:3px;background: #fff;border-radius: 4px;font-family:"Segoe UI";font-size:11px;color: rgba(0,0,0,0.5); float:right;margin-left:206px; margin-top:6px;box-shadow:0px 1px 0px rgba(0,0,0,0.45);}#coments_topic:before {position:absolute;left:-5px;top:6px;content:" ";height:0px;width:0px;border-top:5px solid transparent;border-bottom:5px solid transparent;border-right:5px solid rgba(0,0,0,0.45);}#coments_topic:after {position:absolute;left:-5px;top:5px;content:" ";height:0px;width:0px;border-top:5px solid transparent;border-bottom:5px solid transparent;border-right:5px solid #FFF;}</style>

 <div style="clear:both"></div>
  <div style="width:590px; float:left;">
  <div id="forum_atualiza">
<div id="forum_btns">
<div id="esquerda" style="opacity:0.5"></div>
<div id="atualiza" onclick="pagina.forum('1')"></div>
<div id="direita" onclick="pagina.forum('2')"></div>
</div>
<div class="titulo" style="margin-left:15px; margin-top:10px;">�rea do f�rum</div>
<div style="clear:both"></div>
 <div id="imagem_forum" style="background:url(media/imagens/fundos/espacial.png) repeat;"><div id="frente_imagem"><div id="coments_topic">6</div>
<div id="icn_topico" title="h� 14 horas atr�s"></div><div class="post_forum">postado por <a href="home/wellingt0806" style="color:#fff">wellingt0806</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=wellingt0806&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24544-novidades-nas-regras-da-habbonight"><div id="box_titulo_forum_fixo"><div class="titulo_forum_fixo" title="Novidades nas Regras da HabboNight!">Novidades nas Regras da Hab...</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/fundos/praia_dia.png) repeat;"><div id="frente_imagem"><div id="coments_topic">7</div>
<div id="icn_topico" title="h� 21 horas atr�s"></div><div class="post_forum">postado por <a href="home/robert6966" style="color:#fff">robert6966</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=robert6966&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24532-projetos-a-bordo"><div id="box_titulo_forum_fixo"><div class="titulo_forum_fixo" title="Projetos a bordo!">Projetos a bordo!</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/fundos/espacial.png) repeat;"><div id="frente_imagem"><div id="coments_topic">6</div>
<div id="icn_topico" title="h� 2 dias atr�s"></div><div class="post_forum">postado por <a href="home/-Amanhecer-" style="color:#fff">-Amanhecer-</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-Amanhecer-&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24529-ender-wars-1"><div id="box_titulo_forum_fixo"><div class="titulo_forum_fixo" title="Ender Wars #1">Ender Wars #1</div></div></a>
 </div></div>
 
 <div id="imagem_forum" style="background:url(media/imagens/fundos/1449206984.png) repeat; border-top:2px solid rgb(53,79,111)"><div id="frente_imagem">
 
 <div id="coments_topic">9</div>
<div id="icn_topico" title="h� 2 dias atr�s"></div><div class="post_forum">postado por <a href="home/Reibotsoudlc!" style="color:#fff">Reibotsoudlc!</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=Reibotsoudlc!&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24528-locutores-divos"><div id="box_titulo_forum"><div class="titulo_forum" title="Locutores Divos!">Locutores Divos!</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/padrao.png) repeat; border-top:2px solid rgb(53,79,111)"><div id="frente_imagem">
 
 <div id="coments_topic">0</div>
<div id="icn_topico" title="h� 8 horas atr�s"></div><div class="post_forum">postado por <a href="home/lara2014Loiro" style="color:#fff">lara2014Loiro</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=lara2014Loiro&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24547-programao-off-travestir-"><div id="box_titulo_forum"><div class="titulo_forum" title="PROGRAMA��O '' OFF TRAVESTIR ''">PROGRAMA��O '' OFF TRAVESTI...</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/fundos/espacial.png) repeat; border-top:2px solid rgb(53,79,111)"><div id="frente_imagem">
 
 <div id="coments_topic">10</div>
<div id="icn_topico" title="h� 2 dias atr�s"></div><div class="post_forum">postado por <a href="home/-.Tumblr-" style="color:#fff">-.Tumblr-</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-.Tumblr-&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24526-descubra-se-voce-e-bonito-ou-feio-atraves-deste-metodo-chines"><div id="box_titulo_forum"><div class="titulo_forum" title="Descubra se voc� � bonito ou feio atrav�s deste m�todo chin�...">Descubra se voc� � bonito o...</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/fundos/espacial.png) repeat; border-top:2px solid rgb(53,79,111)"><div id="frente_imagem">
 
 <div id="coments_topic">10</div>
<div id="icn_topico" title="h� 2 dias atr�s"></div><div class="post_forum">postado por <a href="home/-.Tumblr-" style="color:#fff">-.Tumblr-</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-.Tumblr-&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24527-sinais-de-que-voce-deveria-morar-em-outro-pais"><div id="box_titulo_forum"><div class="titulo_forum" title="Sinais de que voc� deveria morar em outro pa�s">Sinais de que voc� deveria ...</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/fundos/espacial.png) repeat; border-top:2px solid rgb(53,79,111)"><div id="frente_imagem">
 
 <div id="coments_topic">8</div>
<div id="icn_topico" title="h� 2 dias atr�s"></div><div class="post_forum">postado por <a href="home/-.Tumblr-" style="color:#fff">-.Tumblr-</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-.Tumblr-&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24525-razoes-pelas-quais-as-pessoas-nao-gostam-de-voce"><div id="box_titulo_forum"><div class="titulo_forum" title="Raz�es pelas quais as pessoas n�o gostam de voc�">Raz�es pelas quais as pesso...</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/padrao.png) repeat; border-top:2px solid rgb(53,79,111)"><div id="frente_imagem">
 
 <div id="coments_topic">1</div>
<div id="icn_topico" title="h� 10 horas atr�s"></div><div class="post_forum">postado por <a href="home/Lucasbnas435" style="color:#fff">Lucasbnas435</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=Lucasbnas435&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24546-minha-ausencia"><div id="box_titulo_forum"><div class="titulo_forum" title="Minha aus�ncia">Minha aus�ncia</div></div></a>
 </div></div>
 <div id="imagem_forum" style="background:url(media/imagens/fundos/1449206984.png) repeat; border-top:2px solid rgb(53,79,111)"><div id="frente_imagem">
 
 <div style="position: absolute;padding:5px;padding-top:3px;padding-bottom:3px;float:right;margin-left:180px; margin-top:6px; color:#fff;text-shadow:0px 1px rgba(0,0,0,0.45);" title="Fechado para coment�rios!"><i class="fa fa-lock"></i></div><div id="coments_topic">11</div>
<div id="icn_topico" title="h� 2 dias atr�s"></div><div class="post_forum">postado por <a href="home/Reibotsoudlc!" style="color:#fff">Reibotsoudlc!</a></div>
 <div style="width:64px; height:85px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=Reibotsoudlc!&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-left:10px;margin-top:-15px; position:absolute;"></div>
  <a href="forum/24523-bonde-da-madru--vagas-abertas-"><div id="box_titulo_forum"><div class="titulo_forum" title="Bonde da Madru - Vagas Abertas ">Bonde da Madru - Vagas Aber...</div></div></a>
 </div></div>
</div>
<div class="titulo" style="margin-left:15px; margin-top:10px;">top music</div>

<div id="top_imagem" style="background:url(http://habbonight.com.br/media/acervo/2015/05/52d0592ee2.png)center repeat;"><div id="top_imagem_escuro">
<div id="tarja_preta">
<div style="padding:10px 5px;"><div class="titulo_tarja" style="font-size:14px;"> Bumbum Granada</div><div class="titulo_tarja" style="font-size:18px;">MCs Zaac & Jerry</div></div></div>
      <div id="roda_verde">1�</div>
</div></div>

<div id="top_imagem_2" style="background:url(http://habbonight.com.br/media/acervo/2015/05/6d9bdbc889.png)center repeat;"><div id="top_imagem_escuro_2">
<div id="tarja_preta_2">
<div style="padding:10px 5px;"><div class="titulo_tarja_2" style="font-size:14px;">Work from home</div><div class="titulo_tarja_2" style="font-size:18px;">Fifth Harmony</div></div></div>
      <div id="roda_laranja">2�</div>
</div></div>

<div id="top_imagem_2" style="background:url(http://habbonight.com.br/media/acervo/2015/05/97c1faead6.png)center repeat;"><div id="top_imagem_escuro_2">
<div id="tarja_preta_2">
<div style="padding:10px 5px;"><div class="titulo_tarja_2" style="font-size:14px;">Faded</div><div class="titulo_tarja_2" style="font-size:18px;">Alan Walker</div></div></div>
      <div id="roda_azul">3�</div>
</div></div>

<div style="clear:both"></div>

<div id="atualiza_tirinhas">
<div id="emblemas_btns" style="margin-top:5px; margin-right:60px;">
<div id="esquerda" style="opacity:0.5"></div>
<div id="direita" onclick="tirinhas('2')"></div>
</div>
<div class="titulo" style="margin-left:15px; margin-top:10px;">�rea das tirinhas</div>

<a href="tirinha/884-o-filho"><div style="width:254px; float:left; border-radius:5px; height:42px;background:url(http://habbonight.com.br/media/acervo/2015/05/fcd4b2d866.png) center no-repeat;border:#1E2731 3px solid; margin-left:10px;margin-bottom:20px;"><div id="desc_tirinhas"><div title="nathancanedo" style="width:25px; height:50px; float:right; margin-left:18px; margin-right:16px; margin-top:-33px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=nathancanedo&action=crr=667&direction=3&head_direction=3&gesture=sml&size=s) -4px -8px;"></div></div><div class="titulotira">O Filho</div></div></a>
<a href="tirinha/883-a-faxineira"><div style="width:254px; float:left; border-radius:5px; height:42px;background:url(http://habbonight.com.br/media/acervo/2015/05/65254271f4.png) center no-repeat;border:#1E2731 3px solid; margin-left:10px;margin-bottom:20px;"><div id="desc_tirinhas"><div title="nathancanedo" style="width:25px; height:50px; float:right; margin-left:18px; margin-right:16px; margin-top:-33px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=nathancanedo&action=crr=667&direction=3&head_direction=3&gesture=sml&size=s) -4px -8px;"></div></div><div class="titulotira">A Faxineira</div></div></a>
<a href="tirinha/882-a-amante"><div style="width:254px; float:left; border-radius:5px; height:42px;background:url(http://habbonight.com.br/media/acervo/2015/05/fadcfeb919.png) center no-repeat;border:#1E2731 3px solid; margin-left:10px;margin-bottom:20px;"><div id="desc_tirinhas"><div title="nathancanedo" style="width:25px; height:50px; float:right; margin-left:18px; margin-right:16px; margin-top:-33px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=nathancanedo&action=crr=667&direction=3&head_direction=3&gesture=sml&size=s) -4px -8px;"></div></div><div class="titulotira">A Amante</div></div></a>
<a href="tirinha/880-o-que-aconteceu-em-1570"><div style="width:254px; float:left; border-radius:5px; height:42px;background:url(http://habbonight.com.br/media/acervo/2015/05/8e95f37d9b.png) center no-repeat;border:#1E2731 3px solid; margin-left:10px;margin-bottom:20px;"><div id="desc_tirinhas"><div title="nathancanedo" style="width:25px; height:50px; float:right; margin-left:18px; margin-right:16px; margin-top:-33px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=nathancanedo&action=crr=667&direction=3&head_direction=3&gesture=sml&size=s) -4px -8px;"></div></div><div class="titulotira">O que aconteceu em 1570?</div></div></a>
<a href="tirinha/878-a-balada"><div style="width:254px; float:left; border-radius:5px; height:42px;background:url(http://habbonight.com.br/media/acervo/2015/05/9cb34de2d9.PNG) center no-repeat;border:#1E2731 3px solid; margin-left:10px;margin-bottom:20px;"><div id="desc_tirinhas"><div title="nathancanedo" style="width:25px; height:50px; float:right; margin-left:18px; margin-right:16px; margin-top:-33px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=nathancanedo&action=crr=667&direction=3&head_direction=3&gesture=sml&size=s) -4px -8px;"></div></div><div class="titulotira">A balada</div></div></a>
<a href="tirinha/877-pobre-por-um-dia"><div style="width:254px; float:left; border-radius:5px; height:42px;background:url(http://habbonight.com.br/media/acervo/2015/05/df049d3781.PNG) center no-repeat;border:#1E2731 3px solid; margin-left:10px;margin-bottom:20px;"><div id="desc_tirinhas"><div title="nathancanedo" style="width:25px; height:50px; float:right; margin-left:18px; margin-right:16px; margin-top:-33px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=nathancanedo&action=crr=667&direction=3&head_direction=3&gesture=sml&size=s) -4px -8px;"></div></div><div class="titulotira">Pobre por um dia</div></div></a>
</div>

<div style="clear:both"></div>

 </div><!-- Fim da div da esquerda !-->
 
 <div style="width:410px; float:right;">
 <div class="titulo" style="margin-left:15px; margin-top:10px;">destaques da habbonight</div>
 <div id="destaque"><div title=".:Loadinge:." style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=.:Loadinge:.&action=sit&direction=2&head_direction=3&gesture=sml&size=m); width:64px; height:110px; margin:-10px; float:left"></div><div id="texto">por estar sempre ligadinho nas promo��es, Participando dos eventos realizado pelo f� site.</div></div>
 <div id="destaque"><div title="-.Tumblr-" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-.Tumblr-&action=sit&direction=2&head_direction=3&gesture=sml&size=m); width:64px; height:110px; margin:-10px; float:left"></div><div id="texto">Por desempenhar um �timo trabalho em seu cargo e ajudar sempre o f� site a crescer.</div></div><div style="clear:both"></div>

 <a href="pixel/3580-loohgatinha-grosser"><div id="destaque_pixel" style="background:url(media/pixels/85d93e651f888d252c913d1b24f74386.png) center repeat"><div id="completa"><div id="texto">Loohgatinha Grosser</div><div id="nota">10</div></div></div></a>
 
<style>
.marcado_rank {background:rgba(0,0,0,0.1)}
</style>
 <div id="barrinha_categorias">
   <div class="barrinha_categorias">
   <div id="barrinha_dentro" class="marcado_rank" onclick="ranking_forum('dia')">Dia</div>
   <div id="barrinha_dentro" onclick="ranking_forum('semana')">Semana</div>
   <div id="barrinha_dentro" onclick="ranking_forum('mensal')">M�s</div>
   <div id="barrinha_dentro" onclick="ranking_forum('sempre')">Sempre</div>
   </div>
  </div>
 <div class="titulo" style="margin-left:15px; margin-top:10px; margin-bottom:10px;">ranking do f�rum</div>
<div id="carrega_rank_forum" style="height:254px;">
 <div id="ranking_forum"><div id="alinha"><div id="pos">1�</div><div style="width:64px; height:61px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=lara2014Loiro&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-top:-15px; margin-left:-5px;"></div><div id="texto"><a href="home/lara2014Loiro" style="color:#fff;">lara2014Loiro</a><br /><span>1 mensagen(s)</span></div></div></div>
 <div id="ranking_forum"><div id="alinha"><div id="pos">2�</div><div style="width:64px; height:61px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=brunno-2011&action=crr=667&direction=2&head_direction=3&gesture=sml&size=m); float:left; margin-top:-15px; margin-left:-5px;"></div><div id="texto"><a href="home/brunno-2011" style="color:#fff;">brunno-2011</a><br /><span>1 mensagen(s)</span></div></div></div>
</div>
 <div style="clear:both"></div>
 
 
 <div id="atualiza_quartos">
 <div id="emblemas_btns" style="margin-top:7px;">
<div id="esquerda" style="opacity:0.5"></div>
<div id="direita" onclick="quartos('2')"></div>
</div>
 <div class="titulo" style="margin-left:15px; margin-top:10px;">quartos parceiros</div>
<a target="_blank" href="https://www.habbo.com.br/room/136828568"><div id="quarto">
	<div id="imagem_q" style="background:url()"></div>
	<div id="texto"><span>Pub Do Edu</span><br />Quarto de: EduDam<br />
Parceiro HabboNight</div>
</div></a>
<a target="_blank" href="https://www.habbo.com.br/room/43478083"><div id="quarto">
	<div id="imagem_q" style="background:url(http://habbonight.com.br/media/acervo/2015/05/7af05719a8.png)"></div>
	<div id="texto"><span>�Batalha dos M�dulos � New g...</span><br />Quarto de: Matlook<br />
Parceiro HabboNight</div>
</div></a>
<a target="_blank" href="https://www.habbo.com.br/hotel?room=136752977"><div id="quarto">
	<div id="imagem_q" style="background:url(http://habbonight.com.br/media/acervo/2015/05/5902aaf08e.png)"></div>
	<div id="texto"><span>BBB � BIG BROTHER BRASIL OFI...</span><br />Quarto de: LucasRenan.<br />
Parceiro HabboNight</div>
</div></a>
<a target="_blank" href="https://www.habbo.com.br/room/121463349"><div id="quarto">
	<div id="imagem_q" style="background:url(http://habbonight.com.br/media/acervo/2015/05/c32875eda7.png)"></div>
	<div id="texto"><span>� POL�CIA DIC EMPREGOS � GOP...</span><br />Quarto de: chaves467<br />
Parceiro HabboNight</div>
</div></a>
</div>

<div id="box_pequena">
  <div class="titulo" style="margin-left:15px;">nossos <b>parceiros</b></div>
 </div>

<div style="float:left;width:400px;">
<marquee>
<a target="_blank" href="http://idhabbo.com.br"><img src="http://i.imgur.com/6JKe5pW.gif" title="IDHabbo" style="margin-left:5px; margin-right:5px;width:120px;height:40px;" /></a>
<a target="_blank" href="http://baccons.com"><img src="http://habbonight.com.br/media/imagens/parceiros/baccons.png" title="Baccons" style="margin-left:5px; margin-right:5px;width:120px;height:40px;" /></a>
<a target="_blank" href="http://www.habbolifeforum.com"><img src="http://images.habbo.com/c_images/album3802/banner_hlf_2.png" title="HabboLifeForum" style="margin-left:5px; margin-right:5px;width:120px;height:40px;" /></a>
<a target="_blank" href="http://puhekupla.com"><img src="http://puhekupla.com/images/banners/button_3.png" title="Puhekupla" style="margin-left:5px; margin-right:5px;width:120px;height:40px;" /></a>
</marquee></div>
 <div style="clear:both;"></div>
 <div id="lets" class="titulo" style="margin-left:3px;">usu�rios online<span style="font-size:11px;"> (Mostrando 26 users) </div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="Skyal" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=Skyal&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>
<div title="AutoNight" style="width:25px; height:38px; float:left; margin-left:3px; margin-right:3px; margin-top:3px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?img_format=gif&user=AutoNight&action=std&direction=2&head_direction=3&gesture=sml&size=s) -4px -8px;"></div>

</div>
<!--<div class="box_pequena" style="margin-left:70px;">Mostrando apenas 2  users</div>-->
<div style="clear:both;"></div>


 </div><!-- Fim da div da direita !-->
<div style="clear:both"></div> 



<div id="titulo_lets" style="margin-top:30px;">
<a href="lets"><div style="background:#faca30; float:left; padding:5px; border-radius:5px; color:#004B67; font-family:Tahoma; font-size:11px; font-weight:bold;box-shadow:0px 2px 0px rgba(0,0,0,0.3);border-bottom:3px solid #94802c;text-shadow:0px 1px rgba(255,255,255,0.5); margin-top:-10px; margin-left:35px;">Mobis</div></a>
<a href="lets-fundos"><div style="background:#faca30; float:left; padding:5px; border-radius:5px; color:#004B67; font-family:Tahoma; font-size:11px; font-weight:bold;box-shadow:0px 2px 0px rgba(0,0,0,0.3);border-bottom:3px solid #94802c;text-shadow:0px 1px rgba(255,255,255,0.5); margin-top:-10px; margin-left:5px;">Fundos</div></a>
<a href="http://habbonight.com.br/pagina/409-regras-da-lets-shopping"><div style="background:#faca30;float: right;padding:5px;border-radius:5px;color:#004B67;font-family:Tahoma;font-size:11px;font-weight:bold;box-shadow:0px 2px 0px rgba(0,0,0,0.3);border-bottom:3px solid #94802c;text-shadow:0px 1px rgba(255,255,255,0.5);margin-top:-10px;margin-right: 39px;">Regras</div><div style="position:absolute;font-family:Tahoma;font-weight:bold;font-size:8px;color:#a4000a;margin-left: 918px;margin-top:-11px;">NEW</div></a>
</div>
<script>
var lets_sho = {
	comprar: function(mobi, quarto){
		if(!confirm('Voc� ir� gastar NightPoints. Deseja prosseguir?')) {
			return false;
		}
		$.ajax({
			type: "POST",
			data: {'carrega':'sim', 'mobi':mobi, 'tipo':'comprar', 'tipop':'mobi'},
			url: "lib/lets.php",
			beforeSend: function(){
			},
			success: function(data){
				if(data == 'sem_fundos'){
					alerta.inicia('Voc� n�o possui NightPoints suficientes!');
				} else if(data == 'ja_comprado'){
					alerta.inicia('Algu�m j� comprou essa mob�lia!');
				} else if(data == 'erro_5min'){
					alerta.inicia('<div id="erro_modal"><i class="fa fa-exclamation-triangle" style="font-size:16px; margin-right:5px;"></i> Voc� acabou de comprar uma mob�lia, aguarde pelo menos 5 minutos para comprar outra!</div><div style="clear:both"></div><div style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?user=MarcioPG.BAN&action=std&direction=4&head_direction=3&gesture=sml&size=b) 0px -10px; width:64px; height:54px; float:right;"></div><div id="quemfez">Enviado por: <a href="home/MarcioPG.BAN">MarcioPG.BAN</a><br>em 07/04/2015 �s 21:47</div><div style="clear:both"></div>');
				} else if(data == 'erro'){
					alerta.inicia('<div id="erro_modal"><i class="fa fa-exclamation-triangle" style="font-size:16px; margin-right:5px;"></i> Essa mob�lia n�o est� liberada para a equipe. Estou de olho em voc� <b></b>!</div><div style="clear:both"></div><div style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?user=MarcioPG.BAN&action=std&direction=4&head_direction=3&gesture=sml&size=b) 0px -10px; width:64px; height:54px; float:right;"></div><div id="quemfez">Enviado por: <a href="home/MarcioPG.BAN">MarcioPG.BAN</a><br>em 07/04/2015 �s 21:47</div><div style="clear:both"></div>');
				} else if(data == 'comprado'){
					alerta.inicia('Voc� comprou a mob�lia com sucesso!!!<br> <a href="'+quarto+'">CLIQUE AQUI</a> para pegar a sua mob�lia!<div style="clear:both"></div><div style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?user=AutoNight&action=std&direction=4&head_direction=3&gesture=sml&size=b) 0px -10px; width:64px; height:54px; float:right;"></div><div id="quemfez">Enviado por: <a href="home/AutoNight">AutoNight</a><br>em 13/06/2016 �s 08:52</div><div style="clear:both"></div>');
				} else {
					alerta.inicia('Algum erro ocorreu durante o processo!');
				} 
			}
		});	
	}
}
</script>
<div style="width:980px; margin:auto; display:table">


<div id="box_lets">
	<div id="mobilia" style="background-image:url(http://habbonight.com.br/media/92f9b9fb63fe3f696e301c8fd38b5d86.gif)">
		<div id="nome_lets" style="text-shadow:-1px 0 #fff, 0 1px #fff,1px 0 #fff, 0 -1px #fff">Mini Estante USVA Br</div>
	</div>
	<div id="lado">
		<div id="preco"><div id="icon"><div>5</div></div></div>
		<div id="indisponivel" title="Comprado por: EduardoSanttos"><div id="icon"></div></div>
		<div id="autor"><div id="i-user" title="Vendido por: Taystee" style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?hb=img&user=Taystee&direction=2&head_direction=3&size=m) -5px -14px;"></div></div>
	</div>
</div>

<div id="box_lets">
	<div id="mobilia" style="background-image:url(http://habbonight.com.br/media/f8919c91ae5df98d5d13663c38c11f7b.gif)">
		<div id="nome_lets" style="text-shadow:-1px 0 #fff, 0 1px #fff,1px 0 #fff, 0 -1px #fff">Mini Estante USVA Br</div>
	</div>
	<div id="lado">
		<div id="preco"><div id="icon"><div>5</div></div></div>
		<div id="indisponivel" title="Comprado por: EduardoSanttos"><div id="icon"></div></div>
		<div id="autor"><div id="i-user" title="Vendido por: Taystee" style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?hb=img&user=Taystee&direction=2&head_direction=3&size=m) -5px -14px;"></div></div>
	</div>
</div>

<div id="box_lets">
	<div id="mobilia" style="background-image:url(http://habbonight.com.br/media/5349347b23df0061ce9253b19091a2f8.png)">
		<div id="nome_lets" style="text-shadow:-1px 0 #fff, 0 1px #fff,1px 0 #fff, 0 -1px #fff">Cama bagun�ada</div>
	</div>
	<div id="lado">
		<div id="preco"><div id="icon"><div>10</div></div></div>
		<div id="indisponivel" title="Comprado por: Reita."><div id="icon"></div></div>
		<div id="autor"><div id="i-user" title="Vendido por: Taystee" style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?hb=img&user=Taystee&direction=2&head_direction=3&size=m) -5px -14px;"></div></div>
	</div>
</div>

<div id="box_lets">
	<div id="mobilia" style="background-image:url(http://habbonight.com.br/media/c95dabe7489040a3ab4eabe7a26c0491.gif)">
		<div id="nome_lets" style="text-shadow:-1px 0 #fff, 0 1px #fff,1px 0 #fff, 0 -1px #fff">Balc�o</div>
	</div>
	<div id="lado">
		<div id="preco"><div id="icon"><div>8</div></div></div>
		<div id="indisponivel" title="Comprado por: EduardoSanttos"><div id="icon"></div></div>
		<div id="autor"><div id="i-user" title="Vendido por: Taystee" style="background:url(http://www.habbo.com.br/habbo-imaging/avatarimage?hb=img&user=Taystee&direction=2&head_direction=3&size=m) -5px -14px;"></div></div>
	</div>
</div>

</div>

<div id="lets_aberto">
<div> NIGHT POINTS</div>
</div>


<div id="pixels_atualiza">
<div id="noticias_btns" style="width:100px; margin-top:5px;">
<div id="esquerda" style="opacity:0.5"></div>
<div id="atualiza" onclick="pixels.pagina('1')"></div>
<div id="direita" onclick="pixels.pagina('2')"></div>
</div>
<div class="titulo" style="margin-left:15px; ">galeria da habbonight</div>

<a href="pixel/3766-meu-avatar-com-hc"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/5dc3b1e64ac84d330d2f02166a874d37.png) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">Meu avatar com HC<div>ElfoAtari79</div></div>
	<div id="nota">10</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=ElfoAtari79&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
<a href="pixel/3765-pixel-arte-e-da-habbonight"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/ea25a0618503314ffffb28e0a952eafb.jpg) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">Pixel-arte  e da ha...<div>bielzinhoo0:D</div></div>
	<div id="nota">4</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=bielzinhoo0:D&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
<a href="pixel/3763-embreminhas-hnphbc"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/73dd1e4be49e93655592cf5f43a9a9a0.png) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">Embreminhas HN/PH/B...<div>-Amanhecer-</div></div>
	<div id="nota">10</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-Amanhecer-&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
<a href="pixel/3762-foguete"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/4a55e9652ea743754e0841a58bc837e3.png) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">Foguete<div>-Amanhecer-</div></div>
	<div id="nota">10</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-Amanhecer-&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
<a href="pixel/3761-robert6966-avatar"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/f5ec805aa58b30cb07138bfd6f4e89ef.png) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">Robert6966 Avatar<div>-Amanhecer-</div></div>
	<div id="nota">10</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=-Amanhecer-&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
<a href="pixel/3760-colorindo-o-saci"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/79ddcd1ae1e0546da568a4d09aeed861.png) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">"Colorindo o Saci"<div>keliarruda8</div></div>
	<div id="nota">9</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=keliarruda8&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
<a href="pixel/3759-colorindo-o-saci"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/6c70ee8266da70f487d8ad423dd0fc34.png) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">Colorindo o Saci<div>xmelccax</div></div>
	<div id="nota">10</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=xmelccax&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
<a href="pixel/3758-colorindo-o-saci"><div id="pixel">
	<div id="imagem_p" style="background:url(media/pixels/a545b3a352cd9396ff739df09ebce27f.png) no-repeat center"><div id="frente_p"></div></div>
	<div id="titulo">Colorindo o Saci<div>_brancodrama</div></div>
	<div id="nota">10</div>
	<div id="autor" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=_brancodrama&action=sml&direction=2&head_direction=3&gesture=sml&size=l)"></div>
</div></a>
</div>


<div style="width:275px; float:left; margin-left:15px;">
	<div class="titulo">ranking de <span style="color:#F8B327">locutores</span></div>
    
  <div id="rankings_outros">
		<div id="pos">1�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=natalhapanda&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/natalhapanda">natalhapanda</a></b> - 54 pontos</div>
	</div>
    
      <div id="rankings_outros">
		<div id="pos">2�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=nathancanedo&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/nathancanedo">nathancanedo</a></b> - 31 pontos</div>
	</div>
    
      <div id="rankings_outros">
		<div id="pos">3�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=LoveGod..&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/LoveGod..">LoveGod..</a></b> - 27 pontos</div>
	</div>
    
      <div id="rankings_outros">
		<div id="pos">4�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=LucasRenan.&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/LucasRenan.">LucasRenan.</a></b> - 23 pontos</div>
	</div>
    
      <div id="rankings_outros">
		<div id="pos">5�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=lara2014Loiro&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/lara2014Loiro">lara2014Loiro</a></b> - 20 pontos</div>
	</div>
    
      

	</div><!-- espacamento final !-->
	
<div style="width:275px; float:left; margin-left:15px;">
	<div class="titulo" style="width:240px;float:left;">ranking de <span style="color:#F8B327">PRESEN�A</span> <font style="font-size:10px;">di�rio</font>
	</div>
	<div style="float:left;margin-top:7px;background-color:rgb(53,79,111);border-radius:5px;height:24px;width:20px;box-shadow:0px 5px 0px rgba(40,61,85,0.65),0px 7px 0px rgba(0,0,0,0.35);font-family:Trebuchet MS;font-size:20px;color:#fff;text-shadow:0px 1px rgba(0,0,0,0.6);padding-left:9px;"><a href="ranking-presenca" style="color:#fff;" title="Confira o ranking completo!">+</a></div>
    	
    
    
	<div id="rankings_outros">
		<div id="pos">1�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=Hastag.Jr&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/Hastag.Jr">Hastag.Jr</a></b> - 2 presen�a(s)</div>
	</div>
	
	<div id="rankings_outros">
		<div id="pos">2�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=Skallz&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/Skallz">Skallz</a></b> - 1 presen�a(s)</div>
	</div>
	
	<div id="rankings_outros">
		<div id="pos">3�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=Willi_&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/Willi_">Willi_</a></b> - 1 presen�a(s)</div>
	</div>
	
	<div id="rankings_outros">
		<div id="pos">4�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=p-=jose=-q&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/p-=jose=-q">p-=jose=-q</a></b> - 1 presen�a(s)</div>
	</div>
	
	<div id="rankings_outros">
		<div id="pos">5�</div><div style="width:30px; background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=Hordwan&action=crr=667&direction=2&head_direction=3&gesture=sml&size=s) 0px -7px; height:38px; float:left;"></div><div id="texto"><b><a href="home/Hordwan">Hordwan</a></b> - 1 presen�a(s)</div>
	</div>
	    
</div>

<!-- espacamento final !-->

<div style="width:404px; float:left; margin-left:10px;">
	<div class="titulo">emblemas do habbo hotel</div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/DE11A.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>DE11A</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/FR857.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>FR857</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/FR856.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>FR856</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/FR855.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>FR855</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/FR850.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>FR850</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/FR848.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>FR848</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/PT099.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>PT099</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/NL461.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>NL461</b> Sem informa��o. - por <b>robert6966</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/PT096.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>PT096</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/PT097.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>PT097</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/UK678.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>UK678</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/UK677.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>UK677</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/NL460.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>NL460</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/PT098.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>PT098</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/NL459.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>NL459</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/NL458.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>NL458</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/NL457.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>NL457</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(https://images.habbo.com/c_images/album1584/ES64A.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>ES64A</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/PT092.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>PT092</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/PT093.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>PT093</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/PT094.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>PT094</b> Sem informa��o. - por <b>-Amanhecer-</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/ES63A.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>ES63A</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/SJG06.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>SJG06</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/ITB18.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>ITB18</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/ITB17.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>ITB17</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/ITB16.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>ITB16</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/ITB15.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>ITB15</b> Sem informa��o. - por <b>thiago18771</b>"></div>
<div style="width:50px; float:left; border-radius:5px; height:50px; margin-left:5px; margin-top:5px;background:url(http://images.habbo.com/c_images/album1584/ITB14.gif) center no-repeat;border:rgba(0,0,0,0.25) 1px solid;" title="<b>ITB14</b> Sem informa��o. - por <b>thiago18771</b>"></div>

</div><!-- espacamento final !-->

<div style="height:10px;clear:both;"></div><!-- espacamento final !-->
  
 </div><!-- Fim da div da bloco1000 !-->
  
</div><!-- Fim da div da div 1000px(conteudo) !-->
<div style="clear:both;"></div><iframe style="background:none; border:none; width:0px; height:0px;" scrolling="no" src="http://habbonight.com.br/playeroff.php"></iframe>

<div id="rodape">
<div id="texto_cima"><div><a href="inicio" style="color:#000;">Home</a> | <a href="pagina/351-histria" style="color:#000;">Sobre-n�s</a> | <a href="habbonight/equipe" style="color:#000;">Equipe</a> | Trabalhe Conosco | Lets Shopping | <a href="nightsena" style="color:#000;">Night Sena</a> | Contate-nos | <a href="https://www.facebook.com/OficialHabbonight" target="_blank" style="color:#000;">Facebook</a> | <a href="http://twitter.com/HabboNight" target="_blank" style="color:#000;">Twitter</a><a target="_blank" title="Host Series - Hospedagem de Sites" href="https://central.hostseries.com.br/aff.php?aff=98" style="margin-left:123px;"><img src="https://hostseries.com.br/banner/afiliados/selo2.png" width="150" height="25" border="0"></a></div></div>
<div id="texto">
� Copyrights � Habbonight 2010 ~ 2016<br />
� Todos direitos reservados � HabboNight. Pl�gio � crime.<br />
<br />
� Layout desenvolvido por MarcioPG.BAN (M�rcio Palheta) e @Mozart (Amadeus Portugal)<br />� Programa��o por MarcioPG.BAN (M�rcio Palheta)
</div>
</div>


	

	<div id="player">
		<div id="avatar_membro2" onclick="playerNight.avatar()" style="background:url(https://www.habbo.com.br/habbo-imaging/avatarimage?user=AutoNight&action=crr=667&direction=2&head_direction=3&gesture=sml&size=l) center;float:left ;width:118px;height:158px; margin-top:-62px; margin-left:-30px; cursor:pointer;"></div>
		<div class="locutor" style="cursor:pointer;" onclick="playerNight.locutor()">AutoNight</div>
		<div class="programa" style="cursor:pointer;" onclick="playerNight.programa()">Tocando todas</div>
		<img src="media/imagens/play.png" usemap="#Map" style="position:absolute; margin:-25px 260px;" border="0"/>
		<map name="Map" id="Map">
			<area shape="circle" coords="72,24,29" href="http://habbonight.com.br/playeroff.php" target="player"  />
			<area shape="circle" coords="23,24,29" href="http://habbonight.com.br/alokadoidao.php" target="player" />
		</map>

		<a href="usuario/usuarios-online"><div id="online" style="cursor:pointer;" title="Usu�rios navegando">12</div></a>
	<div id="ouvin" onclick="playerNight.ouvintes()" style="cursor:pointer;">1</div>
	
	
	</div>
</div>
</body>
</html>

<!--0.37 segundos -->