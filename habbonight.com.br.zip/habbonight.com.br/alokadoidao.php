<script type="text/javascript" src="http://habbonight.com.br/player.js"></script>
	     <script type="text/javascript">
		    new WHMSonic({
			path : "http://habbonight.com.br/WHMSonic.swf",
			source : "stream03.hostseries.com.br:9998",
			volume : 100,
			autoplay : true,
			width: 372,
			height: 60,
			twitter : "https://twitter.com/Habbonight",
			facebook : "https://www.facebook.com/OficialHabbonight",
			logo : "http://habbonight.com.br",
		    });
</script>